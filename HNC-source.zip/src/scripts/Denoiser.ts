import metadata from "@/assets/model/model_metadata.json";
import { InferenceSession, Tensor } from "onnxruntime-react-native";

export class DeepFilterNet {
    private session: InferenceSession | null = null;
    private readonly hopSize: number;
    private readonly fftSize: number;
    private readonly stateInputNames: string[];
    private readonly hasSingleStateTensor: boolean;
    private readonly statesShape: number[];
    private readonly statesLen: number;
    private readonly inputNames: string[];
    private readonly outputNames: string[];

    private streamStates: {
        states: Tensor | Tensor[];
        stateBuffers: Float32Array[];
        attenLimDb: Tensor;
        inputFrameData: Float32Array;
        inputFrame: Tensor;
    } | null = null;

    constructor() {
        this.hopSize = metadata.hop_size;
        this.fftSize = metadata.fft_size;
        this.inputNames = metadata.inputs.map((i) => i.name);
        this.outputNames = metadata.outputs.map((o) => o.name);

        this.stateInputNames = this.inputNames.filter(
            (name) => name !== "input_frame" && name !== "atten_lim_db",
        );
        this.hasSingleStateTensor = this.stateInputNames.includes("states");

        if (this.hasSingleStateTensor) {
            const statesMeta = metadata.inputs.find((i) => i.name === "states");
            if (!statesMeta) throw new Error("Metadata for 'states' input not found.");
            this.statesShape = statesMeta.shape;
            this.statesLen = this.statesShape.reduce((a, b) => a * b, 1);
        } else {
            this.statesShape = [];
            this.statesLen = 0;
        }
    }

    public async loadModel(modelPath: string): Promise<void> {
        try {
            const options: InferenceSession.SessionOptions = {
                executionProviders: ["xnnpack", "cpu"],
                graphOptimizationLevel: "all",
                interOpNumThreads: 1, // Optimized for multi-core mobile CPUs
                intraOpNumThreads: 4,
            };
            this.session = await InferenceSession.create(modelPath, options);
        } catch (e) {
            console.error(`Failed to load model: ${e}`);
            throw e;
        }
    }

    public setupStreaming(attenLimDbValue: number = 0.0): void {
        const { states, stateBuffers, attenLimDb } = this.initStates(attenLimDbValue);
        const inputFrameData = new Float32Array(this.hopSize);
        const inputFrame = new Tensor("float32", inputFrameData, [this.hopSize]);
        this.streamStates = {
            states,
            stateBuffers,
            attenLimDb,
            inputFrameData,
            inputFrame,
        };
    }

    public async processFrame(
        frame: Float32Array,
        dest?: Float32Array,
        destOffset = 0,
    ): Promise<Float32Array> {
        if (!this.session) throw new Error("Session not initialized");
        if (!this.streamStates) throw new Error("Streaming not setup. Call setupStreaming() first.");

        const { states, stateBuffers, attenLimDb, inputFrameData, inputFrame } = this.streamStates;

        inputFrameData.set(frame);

        const feeds: Record<string, Tensor> = {
            input_frame: inputFrame
        };

        if (this.inputNames.includes("atten_lim_db")) {
            feeds["atten_lim_db"] = attenLimDb;
        }

        if (this.hasSingleStateTensor) {
            feeds["states"] = states as Tensor;
        } else {
            const stateTensors = states as Tensor[];
            for (let j = 0; j < stateTensors.length; j++) {
                feeds[this.stateInputNames[j]] = stateTensors[j];
            }
        }

        const results = await this.session.run(feeds);

        // Copy output state data back into the pre-allocated state tensors
        // (buffer reuse — no new Tensor objects per frame, avoiding GC churn
        // across the 100k+ frames of a long file).
        if (this.hasSingleStateTensor) {
            const nextStateRaw = results[this.outputNames[1]].data as Float32Array;
            stateBuffers[0].set(nextStateRaw);
        } else {
            for (let j = 0; j < this.stateInputNames.length; j++) {
                const nextMultiStateRaw = results[this.outputNames[j + 1]].data as Float32Array;
                stateBuffers[j].set(nextMultiStateRaw);
            }
        }

        // Write output directly into `dest` when provided, avoiding an extra
        // allocation + copy in the caller's hot loop.
        const outFrameRaw = results[this.outputNames[0]].data as Float32Array;
        if (dest) {
            dest.set(outFrameRaw, destOffset);
            return dest;
        }
        return outFrameRaw;
    }

    public async release(): Promise<void> {
        if (this.session) {
            try {
                await this.session.release();
                this.session = null;
                this.streamStates = null;
            } catch (e) {
                console.error("Failed to release InferenceSession:", e);
            }
        }
    }

    public resetStates(): void {
        this.streamStates = null;
    }

    private initStates(attenLimDbValue: number = 0.0): {
        states: Tensor | Tensor[];
        stateBuffers: Float32Array[];
        attenLimDb: Tensor;
    } {
        let states: Tensor | Tensor[];
        let stateBuffers: Float32Array[];

        if (this.hasSingleStateTensor) {
            const buffer = new Float32Array(this.statesLen);
            stateBuffers = [buffer];
            states = new Tensor("float32", buffer, this.statesShape);
        } else {
            states = [];
            stateBuffers = [];
            const stateInputsMeta = metadata.inputs.filter((i) =>
                this.stateInputNames.includes(i.name),
            );
            for (const meta of stateInputsMeta) {
                const size = meta.shape.reduce((a, b) => a * b, 1);
                const buffer = new Float32Array(size);
                stateBuffers.push(buffer);
                states.push(
                    new Tensor("float32", buffer, meta.shape),
                );
            }
        }

        const attenLimDb = new Tensor("float32", new Float32Array([attenLimDbValue]), [1]);
        return { states, stateBuffers, attenLimDb };
    }

    /**
     * Denoise audio feed(s).
     */
    public async denoise(
        audio: Float32Array | Float32Array[],
        onProgress?: ((p: number) => void) | ((p: number, i: number) => void),
        attenLimDbValue: number = 0.0,
    ): Promise<Float32Array | Float32Array[]> {
        if (!this.session) {
            throw new Error("Model not loaded. Please call loadModel() first.");
        }

        const isArray = Array.isArray(audio);
        const feeds = isArray ? audio : [audio];

        // Validate amplitude range for each feed
        for (const feed of feeds) {
            let maxAmplitude = 0;
            for (let i = 0; i < feed.length; i++) {
                const abs = Math.abs(feed[i]);
                if (abs > maxAmplitude) maxAmplitude = abs;
            }
            if (maxAmplitude > 2.0) {
                console.warn(`Audio amplitude (${maxAmplitude}) exceeds expected [-1.0, 1.0] range. Ensure input is float32 PCM.`);
            }
        }

        const results = await this.runDenoiseLoop(feeds, onProgress, attenLimDbValue);

        return isArray ? results : results[0];
    }

    private async runDenoiseLoop(
        audioFeeds: Float32Array[],
        onProgress?: ((p: number) => void) | ((p: number, i: number) => void),
        attenLimDbValue: number = 0.0,
    ): Promise<Float32Array[]> {
        if (!this.session) throw new Error("Session not initialized");

        const numFeeds = audioFeeds.length;
        const origLen = audioFeeds[0].length;

        // ALIGNMENT: Prepend fftSize zeros for delay compensation
        const hopSizePadding = (this.hopSize - (origLen % this.hopSize)) % this.hopSize;
        const totalPadding = this.fftSize + hopSizePadding;
        const paddedLen = origLen + totalPadding;
        const numSteps = Math.ceil(paddedLen / this.hopSize);

        // Prepare resources for all feeds
        const feedStates = audioFeeds.map(() => {
            const { states, attenLimDb } = this.initStates(attenLimDbValue);
            const inputFrameData = new Float32Array(this.hopSize);
            const inputFrame = new Tensor("float32", inputFrameData, [this.hopSize]);
            const paddedAudio = new Float32Array(paddedLen);
            return {
                states,
                attenLimDb,
                inputFrameData,
                inputFrame,
                paddedAudio,
                enhancedAudio: new Float32Array(numSteps * this.hopSize),
            };
        });

        // Initialize padded audio buffers
        for (let i = 0; i < numFeeds; i++) {
            feedStates[i].paddedAudio.set(audioFeeds[i], this.fftSize);
        }

        let lastReportedProgress = -1;

        for (let step = 0; step < numSteps; step++) {
            const start = step * this.hopSize;

            const inferencePromises = feedStates.map(async (f) => {
                f.inputFrameData.set(f.paddedAudio.subarray(start, start + this.hopSize));

                const feeds: Record<string, Tensor> = {
                    input_frame: f.inputFrame
                };

                if (this.inputNames.includes("atten_lim_db")) {
                    feeds["atten_lim_db"] = f.attenLimDb;
                }

                if (this.hasSingleStateTensor) {
                    feeds["states"] = f.states as Tensor;
                } else {
                    const stateTensors = f.states as Tensor[];
                    for (let j = 0; j < stateTensors.length; j++) {
                        feeds[this.stateInputNames[j]] = stateTensors[j];
                    }
                }

                const results = await this.session!.run(feeds);

                const outFrameRaw = results[this.outputNames[0]].data as Float32Array;
                f.enhancedAudio.set(outFrameRaw, start);

                if (this.hasSingleStateTensor) {
                    const nextStateRaw = results[this.outputNames[1]].data as Float32Array;
                    f.states = new Tensor("float32", nextStateRaw, this.statesShape);
                } else {
                    const newStates: Tensor[] = [];
                    for (let j = 0; j < this.stateInputNames.length; j++) {
                        const nextMultiStateRaw = results[this.outputNames[j + 1]].data as Float32Array;
                        const originalShape = (f.states as Tensor[])[j].dims;
                        newStates.push(new Tensor("float32", nextMultiStateRaw, originalShape));
                    }
                    f.states = newStates;
                }
            });

            await Promise.all(inferencePromises);

            if (onProgress) {
                const progress = Math.round(((step + 1) / numSteps) * 100);
                if (progress > lastReportedProgress) {
                    if (numFeeds > 1) {
                        for (let i = 0; i < numFeeds; i++) {
                            (onProgress as (p: number, i: number) => void)(progress, i);
                        }
                    } else {
                        (onProgress as (p: number) => void)(progress);
                    }
                    lastReportedProgress = progress;
                }
            }
        }

        return feedStates.map(f => f.enhancedAudio.slice(this.fftSize, origLen + this.fftSize));
    }

}